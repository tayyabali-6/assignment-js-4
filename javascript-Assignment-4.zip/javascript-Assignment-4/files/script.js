
let string = 'I love my country Pakistan <br> I like my city Faisalabad <br> I love my homeland'
let cities = ['Faisalabad', 'Lahor', 'Karachi', 'Islambad', 'Quatta', 'Kashmir']

// function ConvertLowerCase() {
//   let lowerCase = string.toLowerCase()
//   document.getElementById('Result').innerHTML = lowerCase

// }

// function ConvertUperwerCase() {
//   let UpererCase = string.toUpperCase()
//   document.getElementById('Result').innerHTML = UpererCase

// }


// Capitalize = () => {
//   document.getElementById('Result').innerHTML = string
//   document.getElementById('Result').style.textTransform = 'capitalize'
//   console.log();
// }

// betterFormating = () => {
//   let inputField = document.getElementById('inputField').value
//   if (!inputField) {
//     alert('Enter your some value')
//     return;
//   }
//   document.getElementById('Result').innerHTML = inputField
//   document.getElementById('Result').style.textTransform = 'capitalize'
// }

// printAllCities = () => {
//   for (let i = 0; i < cities.length; i++) {
//     document.getElementById('Result').innerHTML += cities[i] + '<br />'
//   }
// }

// addlist = () => {
//   let inputField = document.getElementById('inputField').value
//   if (!inputField) {
//     alert('Please Enter Your City Name')
//   }
//   let toLowerCase = inputField.toLowerCase()
//   let toUpperCase = toLowerCase.slice(0, 1).toUpperCase()
//   let Alletters = toUpperCase + toLowerCase.slice(1)

//   let foundcity = false
//   foundcity = cities.includes(Alletters)

//   if (foundcity) {
//     foundcity = true
//     let html = '<span style="color:red;font-size:20px;font-weight:bold;">' + Alletters + '</span> All ready in list'
//     document.getElementById('Result').innerHTML = html

//   } else {
//     cities.push(Alletters)
//     let html = '<span style="color:red;font-size:20px;fon-weight:bold;">' + Alletters + '</span> Add your City in list'
//     document.getElementById('Result').innerHTML = html

//   }

// }

// checkList = () => {
//   let inputField = document.getElementById('inputField').value
//   if (!inputField) {
//     alert('Please Enter Your City Name')
//   }
//   let toLowerCase = inputField.slice(1).toLowerCase()
//   let toUpperCase = inputField.slice(0, 1).toUpperCase()
//   let Alletters = toUpperCase + toLowerCase
//   let foundcity = false

//   foundcity = cities.includes(Alletters)
//   //  console.log(Alletters);

//   if (foundcity) {
//     foundcity = true
//     let html = '<span style="color:red;font-size:20px;font-weight:bold;">' + Alletters + '</span> Allready in list'
//     document.getElementById('Result').innerHTML = html
//   } else {
//     cities.push(Alletters)
//     let html = '<span style="color:red;font-size:20px;font-weight:bold;">' + Alletters + '</span> Add your City in list'
//     document.getElementById('Result').innerHTML = html
//   }

// }


// FindWord = () => {
//   let orignalText = string.toLowerCase()
//   let inputField = document.getElementById('inputField').value

//   if (!inputField) {
//     alert('Enter your value')
//     return;
//   }
//   inputField = inputField.toLowerCase()
//   let findWord = orignalText.indexOf(inputField)
//   if (findWord != -1) {
//     let html = '<span style="color:green;font-size:20px;font-weight:bold;">' + findWord + '</span> IndexOf'
//     document.getElementById('Result').innerHTML = html

//   } else {
//     let html = '<span style="color:red;font-size:20px;font-weight:bold;">Index is not finde</span> '
//     document.getElementById('Result').innerHTML = html

//   }
// }


// ReplaceWord = () => {
//   let inputField = document.getElementById('inputField').value
//   let stringlowercase = string.toLowerCase()
//   let inputField2 = inputField.toLowerCase()
//   if (!inputField) {
//     return alert('Enter your value')
//   }
//   let prompt12 = prompt('enter your word')
//   let replaceword = stringlowercase.replaceAll(inputField2, prompt12, alert('Congratulations'))
//   console.log(replaceword);
//   document.getElementById('Result').innerHTML = replaceword


// }

// clearOutput = () => {
//   document.getElementById('Result').innerHTML = ""

// }
// clearInput = () => {
//   document.getElementById('inputField').value = ""
//   console.log();
// }
















ConvertLowerCase = () => {
  document.getElementById('Result').innerHTML = string.toLowerCase()
  }
  
  ConvertUperwerCase = () => {
  document.getElementById('Result').innerHTML = string.toUpperCase()
  }
  
  Capitalize = () => {
    
    document.getElementById('Result').innerHTML = string
    document.getElementById('Result').style.textTransform='capitalize'
  }

  betterFormating = () => {
   let inputField =  document.getElementById('inputField').value
    if (!inputField) {
      return alert('Enter your Value')
    }
    document.getElementById('Result').innerHTML = inputField
    document.getElementById('Result').style.textTransform = 'capitalize'
  }
  
  printAllCities = () => {
    for (let index = 0; index < cities.length; index++) {
      document.getElementById('Result').innerHTML +=  cities[index] + "<br />"     
    }
  }

  addlist = () => {
   let inputField = document.getElementById('inputField').value
    if (!inputField) {
      return alert('Enter your Value')
    }
    let toLowerCase = inputField.slice(1).toLowerCase()
    let toUpperCase = inputField.charAt(0).toUpperCase()
    let Alletters = toUpperCase + toLowerCase

    let foundcity = false
   foundcity = cities.includes(Alletters)
   if (!foundcity) {
    foundcity = true
    cities.push(Alletters)
   }else{
    alert('allready iincludes')
   }
  }

  FindWord = () => {
    
  }